package com.example.myplanner;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.fragment.app.FragmentTransaction;

public class RegisterFragment extends Fragment {

    private EditText etUsername, etPassword, etEmail, etFullName; // Declare the input fields
    private Button btnRegister;

    public RegisterFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_register, container, false);

        // Initialize the input fields and button
        etUsername = view.findViewById(R.id.usernameEditText);
        etPassword = view.findViewById(R.id.passwordEditText);
        btnRegister = view.findViewById(R.id.RegisterButton);

        // Set up the register button click event
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser(); // Call the method to register the user
            }
        });

        // Set up the return button to navigate back to LoginFragment
        Button btnReturnToLogin = view.findViewById(R.id.ReturnButton);
        btnReturnToLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadLoginFragment();
            }
        });

        return view;
    }

    // Method to handle user registration
    private void registerUser() {
        // Get input from the fields
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String fullName = etFullName.getText().toString().trim();

        // Simple validation
        if (username.isEmpty() || password.isEmpty() || email.isEmpty() || fullName.isEmpty()) {
            Toast.makeText(getActivity(), "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create a new User object with the provided data
        User newUser = new User(username, password, email, fullName);

        // For now, just show a toast message with the registered username (or save to database in the future)
        Toast.makeText(getActivity(), "User " + newUser.getUsername() + " registered successfully!", Toast.LENGTH_SHORT).show();

        // TODO: You can now save this user to a database, send it to an API, or store it locally as needed
    }

    // Method to load the LoginFragment
    private void loadLoginFragment() {
        LoginFragment loginFragment = new LoginFragment();
        FragmentTransaction transaction = getParentFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, loginFragment); // Make sure this ID matches your activity's fragment container
        transaction.addToBackStack(null); // Optional: Add to back stack to allow navigation back
        transaction.commit();
    }
}
